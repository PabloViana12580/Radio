/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package radio;

/**
 *
 * @author richi
 */
public class GUI extends Carro{
   
    public static void main(String[] args) {
        Carro grupo=new Carro();
        grupo.estado();
        System.out.print(grupo.estado);
    }
    
}
